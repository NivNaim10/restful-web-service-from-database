/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package apiexample.client;

import java.io.IOException;

/**
 *
 * @author User
 */
public class APIExampleClient {

    public static void main(String[] args) throws IOException {
        
        HttpURLConnectionMethods httpRequest = new HttpURLConnectionMethods();
        httpRequest.sendHttpGETRequest();
        httpRequest.sendHttpPOSTRequest();
    }
    
}
