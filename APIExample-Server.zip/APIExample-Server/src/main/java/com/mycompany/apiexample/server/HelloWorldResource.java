/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/GenericResource.java to edit this template
 */
package com.mycompany.apiexample.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.enterprise.context.RequestScoped;
import javax.ws.rs.POST;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author User
 */
@Path("HelloWorld")
@RequestScoped
public class HelloWorldResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of HelloWorldResource
     */
    public HelloWorldResource() {
    }

    /**
     * Retrieves representation of an instance of com.mycompany.apiexample.server.HelloWorldResource
     * @return an instance of java.lang.String
     */
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getHtml() {

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String userName = "NivNaim";
            String password = "2001";           
            String url = "jdbc:sqlserver://DESKTOP-ETSS4MS\\SQLEXPRESS:1433;databaseName=ParkingManagementSystem";
            Connection conn;
            conn = DriverManager.getConnection(url, userName, password);           
            System.out.println("connection created!");
            String sql = "exec displayUserDetails @userID = ?";
            PreparedStatement pst;
            pst = conn.prepareStatement(sql);
            pst.setInt(1, 1);
            ResultSet rs = pst.executeQuery();
            
            if(rs.next()){
                
                return rs.getString("userName");
            }
            
            pst.close();
            conn.close();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(HelloWorldResource.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(HelloWorldResource.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return "<html><body>Hey Niv!</body></html>";
    }

    /**
     * PUT method for updating or creating an instance of HelloWorldResource
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void putHtml(String content) {
    }
    
    @POST
    @Path("niv")
    //@Consumes(MediaType.APPLICATION_JSON)
    public String postHtml(String content) {

        return content;
    }
    
}
