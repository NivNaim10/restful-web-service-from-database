/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.apiexample.server;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author User
 */
public class JPAEntityLifecycleEvents {
    
    //Properties
    private EntityManagerFactory emf;
    private EntityManager em;

    //Gatter
    public EntityManagerFactory getEmf() {
        return emf;
    }

    public EntityManager getEm() {
        return em;
    }
    
    public JPAEntityLifecycleEvents(String PUname){
        
        emf = Persistence.createEntityManagerFactory(PUname);
        em = emf.createEntityManager();
    }
    
    public void createObjectInDB(Object ob){
        
        try{
            em.getTransaction().begin();
            em.persist(ob);
            em.getTransaction().commit();
        }
        catch(Exception ex){
            ex.printStackTrace();
            em.getTransaction().rollback();
        }
    }
    
    public void updateObjectInDB(Object ob){

        try{
            em.getTransaction().begin();
            em.merge(ob);
            em.getTransaction().commit();
        }
        catch(Exception ex){
            ex.printStackTrace();
            em.getTransaction().rollback();
        }
    }
    
    public void removeObjectFromDB(Object ob){

        try{
            em.getTransaction().begin();
            em.remove(ob);
            em.getTransaction().commit();
        }
        catch(Exception ex){
            ex.printStackTrace();
            em.getTransaction().rollback();
        }
    }
    
    public Object findObjectFromDB(Object ob, int primeryKey){

        ob = em.find(ob.getClass(), primeryKey);

        return ob;
    }
}
